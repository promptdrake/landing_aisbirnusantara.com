<template>
  <Page />
</template>

<script setup>
import Page from './components/Page.vue'
import './styles/main.css'
</script>

<style>
html, body {
  margin: 0;
  padding: 0;
}
</style>
