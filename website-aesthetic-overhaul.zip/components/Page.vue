<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'

const activeSection = ref('why')
let observer

onMounted(() => {
  const sections = Array.from(document.querySelectorAll('section[id]'))

  observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          activeSection.value = entry.target.id
        }
      })
    },
    {
      root: null,
      threshold: 0.4,
      rootMargin: '-20% 0px -50% 0px',
    }
  )

  sections.forEach((section) => observer.observe(section))
})

onBeforeUnmount(() => {
  if (observer) {
    observer.disconnect()
  }
})
</script>

<template>
  <div class="page">
    <header class="nav glass reveal">
      <div class="brand">
        <span class="brand-mark">A</span>
        <div>
          <p class="brand-name">Aisbir Cloud Nusantara</p>
          <p class="brand-tag">Cloud hosting provider</p>
        </div>
      </div>
      <input id="nav-toggle" class="nav-toggle" type="checkbox" />
      <label class="nav-toggle-label" for="nav-toggle">
        <span></span>
        <span></span>
        <span></span>
      </label>
      <div class="nav-menu">
        <nav class="nav-links">
          <a href="#why" :class="{ active: activeSection === 'why' }">Why Choose Us</a>
          <a href="#pricing" :class="{ active: activeSection === 'pricing' }">Pricing Tier</a>
          <a href="#checkout" :class="{ active: activeSection === 'checkout' }">Checkout system</a>
          <a href="#faq" :class="{ active: activeSection === 'faq' }">FAQ</a>
          <a href="#support" :class="{ active: activeSection === 'support' }">Support Contact</a>
        </nav>
        <div class="nav-actions">
          <a class="btn ghost" href="#support">Hubungi Support</a>
          <a class="btn primary" href="#pricing">Order Sekarang</a>
        </div>
      </div>
    </header>

    <main>
      <section class="hero">
        <div class="hero-content reveal">
          <p class="eyebrow">Cloud hosting Indonesia</p>
          <h1>Hosting cepat, stabil, dan ramah komunitas untuk semua kebutuhan.</h1>
          <p class="lead">
            Aisbir Cloud Nusantara menghadirkan layanan hosting dengan datacenter
            Indonesia, uptime tinggi, dan dukungan komunitas yang siap membantu.
          </p>
          <div class="hero-actions">
            <a class="btn primary" href="#pricing">Lihat Paket</a>
            <a class="btn ghost" href="#support">Kontak Support</a>
          </div>
          <div class="hero-metrics">
            <div>
              <p class="metric-title">Datacenter</p>
              <p class="metric-value">Indonesia</p>
            </div>
            <div>
              <p class="metric-title">Uptime</p>
              <p class="metric-value">99%</p>
            </div>
            <div>
              <p class="metric-title">Support</p>
              <p class="metric-value">Comunity</p>
            </div>
          </div>
        </div>
        <div class="hero-panel glass reveal delay-1">
          <div class="panel-card">
            <p class="panel-title">Bandwidth</p>
            <p class="panel-value">Unlimited</p>
            <div class="panel-tags">
              <span>Website</span>
              <span>Bisnis</span>
              <span>Store</span>
            </div>
          </div>
          <div class="panel-card accent">
            <p class="panel-title">Uptime monitor</p>
            <p class="panel-value">99% stabil</p>
            <div class="panel-bars">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
          <div class="panel-card">
            <p class="panel-title">Datacenter</p>
            <p class="panel-value">Indonesia</p>
            <p class="panel-sub">Low latency untuk pengguna lokal.</p>
          </div>
        </div>
      </section>

      <section id="why" class="section">
        <div class="section-header reveal">
          <h2>Why Choose Us</h2>
          <p>Fokus pada performa, stabilitas, dan pengalaman terbaik di Indonesia.</p>
        </div>
        <div class="feature-grid">
          <article class="feature-card glass reveal delay-1">
            <h3>Indonesia Datacenter</h3>
            <p>Latensi rendah dengan infrastruktur lokal yang teruji.</p>
          </article>
          <article class="feature-card glass reveal delay-2">
            <h3>99% Uptime</h3>
            <p>Jaringan stabil untuk memastikan layanan selalu online.</p>
          </article>
          <article class="feature-card glass reveal delay-3">
            <h3>Comunity Support</h3>
            <p>Komunitas aktif yang siap berbagi dan membantu.</p>
          </article>
        </div>
      </section>

      <section id="pricing" class="section">
        <div class="section-header reveal">
          <h2>Pricing Tier</h2>
          <p>Paket fleksibel untuk kebutuhan personal hingga bisnis.</p>
        </div>
        <div class="pricing-table glass reveal">
          <div class="pricing-row pricing-header">
            <span>Tier</span>
            <span>Harga</span>
            <span>Bandwidth</span>
            <span>Storage</span>
            <span>CPU</span>
            <span>Domain</span>
            <span>SSL</span>
            <span>Aksi</span>
          </div>
          <div class="pricing-row">
            <span class="tier">Warga</span>
            <span>Rp 7.000</span>
            <span>Unlimited</span>
            <span>5 GB</span>
            <span>2</span>
            <span>2</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row">
            <span class="tier">Pendekar</span>
            <span>Rp 15.000</span>
            <span>Unlimited</span>
            <span>15 GB</span>
            <span>3</span>
            <span>Unlimited</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row highlight">
            <span class="tier">Mahapatih</span>
            <span>Rp 20.000</span>
            <span>Unlimited</span>
            <span>20 GB</span>
            <span>4</span>
            <span>Unlimited</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row">
            <span class="tier">Jendral</span>
            <span>Rp 50.000</span>
            <span>Unlimited</span>
            <span>50 GB</span>
            <span>10</span>
            <span>Unlimited</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row">
            <span class="tier">Pelajar</span>
            <span>Rp 5.000</span>
            <span>Unlimited</span>
            <span>2 GB</span>
            <span>1</span>
            <span>2</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
        </div>
      </section>

      <section id="checkout" class="section">
        <div class="section-header reveal">
          <p class="eyebrow">Checkout system</p>
          <h2>Cara Kerja Website Kita</h2>
          <p>Kamu bingung gimana cara kerja website kita? Sini mimin kasih tau</p>
        </div>
        <div class="flow reveal">
          <article class="flow-step glass">
            <h3>Buat Akun</h3>
            <p>Masukkan Nama, Email, Dan password kamu. Tenang kami akan simpan baik baik!</p>
          </article>
          <article class="flow-step glass">
            <h3>Pilih Produk</h3>
            <p>Pilih apapun yang kamu butuhkan, Jika yang kamu butuhkan tidak ada hubungi di livechat.</p>
          </article>
          <article class="flow-step glass">
            <h3>Checkout</h3>
            <p>Pilih metode pembayaran dan lakukan checkout, lalu cek emailmu secara berkala.</p>
          </article>
        </div>
      </section>

      <section id="faq" class="section">
        <div class="section-header reveal">
          <h2>FAQ</h2>
          <p>Jawaban singkat untuk pertanyaan yang sering masuk.</p>
        </div>
        <div class="faq-list reveal">
          <details class="faq-item glass">
            <summary>Apakah tersedia migrasi gratis?</summary>
            <p>Ya, tim kami membantu migrasi dasar untuk website yang aktif.</p>
          </details>
          <details class="faq-item glass">
            <summary>Metode pembayaran apa saja yang tersedia?</summary>
            <p>Kami menerima transfer bank, e-wallet, dan virtual account.</p>
          </details>
          <details class="faq-item glass">
            <summary>Bagaimana cara menghubungi support?</summary>
            <p>Gunakan WhatsApp atau Telegram pada bagian Support Contact.</p>
          </details>
        </div>
      </section>

      <section id="support" class="support glass reveal">
        <div class="support-content">
          <h2>Support Contact</h2>
          <p>Pilih jalur kontak yang paling nyaman untuk Anda.</p>
          <div class="cta-actions">
            <a class="btn primary" href="https://wa.me/6285173118646" target="_blank" rel="noreferrer">WhatsApp Support</a>
            <a class="btn ghost" href="https://t.me/aisbirnusantara" target="_blank" rel="noreferrer">Telegram Support</a>
          </div>
        </div>
        <img class="support-image" src="/support.svg" alt="Support" />
      </section>
    </main>

    <footer class="footer glass">
      <div>
        <p class="footer-title">Aisbir Cloud Nusantara</p>
        <p class="footer-text">Cloud hosting untuk semua. Work hour: 08:00 - 21:00</p>
      </div>
      <div class="footer-links">
        <a href="https://status.aisbirnusantara.com" target="_blank" rel="noreferrer">Status</a>
        <a href="https://dash.aisbirnusantara.com" target="_blank" rel="noreferrer">Dashboard</a>
      </div>
    </footer>
  </div>
</template>
