<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'

const activeSection = ref('why')
let observer

onMounted(() => {
  const sections = Array.from(document.querySelectorAll('section[id]'))

  observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          activeSection.value = entry.target.id
        }
      })
    },
    {
      root: null,
      threshold: 0.4,
      rootMargin: '-20% 0px -50% 0px',
    }
  )

  sections.forEach((section) => observer.observe(section))
})

onBeforeUnmount(() => {
  if (observer) {
    observer.disconnect()
  }
})
</script>

<template>
  <div class="page">
    <header class="nav glass reveal">
      <div class="brand">
        <span class="brand-mark">A</span>
        <div>
          <p class="brand-name">Aisbir Cloud Nusantara</p>
          <p class="brand-tag">Cloud hosting provider</p>
        </div>
      </div>
      <input id="nav-toggle" class="nav-toggle" type="checkbox" />
      <label class="nav-toggle-label" for="nav-toggle">
        <span></span>
        <span></span>
        <span></span>
      </label>
      <div class="nav-menu">
        <nav class="nav-links">
          <a href="#why" :class="{ active: activeSection === 'why' }">Why Choose Us</a>
          <a href="#pricing" :class="{ active: activeSection === 'pricing' }">Pricing Tier</a>
          <a href="#checkout" :class="{ active: activeSection === 'checkout' }">Checkout system</a>
          <a href="#faq" :class="{ active: activeSection === 'faq' }">FAQ</a>
          <a href="#support" :class="{ active: activeSection === 'support' }">Support Contact</a>
        </nav>
        <div class="nav-actions">
          <a class="btn ghost" href="#support">Hubungi Support</a>
          <a class="btn primary" href="#pricing">Order Sekarang</a>
        </div>
      </div>
    </header>

    <main>
      <section class="hero">
        <div class="hero-content reveal">
          <p class="eyebrow">Cloud hosting Indonesia</p>
          <h1>Hosting cepat, stabil, dan ramah komunitas untuk semua kebutuhan.</h1>
          <p class="lead">
            Aisbir Cloud Nusantara menghadirkan layanan hosting dengan datacenter
            Indonesia, uptime tinggi, dan dukungan komunitas yang siap membantu.
          </p>
          <div class="hero-actions">
            <a class="btn primary" href="#pricing">Lihat Paket</a>
            <a class="btn ghost" href="#support">Kontak Support</a>
          </div>
          <div class="hero-metrics">
            <div>
              <p class="metric-title">Datacenter</p>
              <p class="metric-value">Indonesia</p>
            </div>
            <div>
              <p class="metric-title">Uptime</p>
              <p class="metric-value">99%</p>
            </div>
            <div>
              <p class="metric-title">Support</p>
              <p class="metric-value">Comunity</p>
            </div>
          </div>
        </div>
        <div class="hero-panel glass reveal delay-1">
          <div class="panel-card">
            <p class="panel-title">Bandwidth</p>
            <p class="panel-value">Unlimited</p>
            <div class="panel-tags">
              <span>Website</span>
              <span>Bisnis</span>
              <span>Store</span>
            </div>
          </div>
          <div class="panel-card accent">
            <p class="panel-title">Uptime monitor</p>
            <p class="panel-value">99% stabil</p>
            <div class="panel-bars">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
          <div class="panel-card">
            <p class="panel-title">Datacenter</p>
            <p class="panel-value">Indonesia</p>
            <p class="panel-sub">Low latency untuk pengguna lokal.</p>
          </div>
        </div>
      </section>

      <section id="why" class="section">
        <div class="section-header reveal">
          <h2>Why Choose Us</h2>
          <p>Fokus pada performa, stabilitas, dan pengalaman terbaik di Indonesia.</p>
        </div>
        <div class="feature-grid">
          <article class="feature-card glass reveal delay-1">
            <h3>Indonesia Datacenter</h3>
            <p>Latensi rendah dengan infrastruktur lokal yang teruji.</p>
          </article>
          <article class="feature-card glass reveal delay-2">
            <h3>99% Uptime</h3>
            <p>Jaringan stabil untuk memastikan layanan selalu online.</p>
          </article>
          <article class="feature-card glass reveal delay-3">
            <h3>Comunity Support</h3>
            <p>Komunitas aktif yang siap berbagi dan membantu.</p>
          </article>
        </div>
      </section>

      <section id="pricing" class="section">
        <div class="section-header reveal">
          <h2>Pricing Tier</h2>
          <p>Paket fleksibel untuk kebutuhan personal hingga bisnis.</p>
        </div>
        <div class="pricing-table glass reveal">
          <div class="pricing-row pricing-header">
            <span>Tier</span>
            <span>Harga</span>
            <span>Bandwidth</span>
            <span>Storage</span>
            <span>CPU</span>
            <span>Domain</span>
            <span>SSL</span>
            <span>Aksi</span>
          </div>
          <div class="pricing-row">
            <span class="tier">Warga</span>
            <span>Rp 7.000</span>
            <span>Unlimited</span>
            <span>5 GB</span>
            <span>2</span>
            <span>2</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row">
            <span class="tier">Pendekar</span>
            <span>Rp 15.000</span>
            <span>Unlimited</span>
            <span>15 GB</span>
            <span>3</span>
            <span>Unlimited</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row highlight">
            <span class="tier">Mahapatih</span>
            <span>Rp 20.000</span>
            <span>Unlimited</span>
            <span>20 GB</span>
            <span>4</span>
            <span>Unlimited</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row">
            <span class="tier">Jendral</span>
            <span>Rp 50.000</span>
            <span>Unlimited</span>
            <span>50 GB</span>
            <span>10</span>
            <span>Unlimited</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
          <div class="pricing-row">
            <span class="tier">Pelajar</span>
            <span>Rp 5.000</span>
            <span>Unlimited</span>
            <span>2 GB</span>
            <span>1</span>
            <span>2</span>
            <span class="status on">Enabled</span>
            <button class="btn primary">Add To Cart</button>
          </div>
        </div>
      </section>

      <section id="checkout" class="section">
        <div class="section-header reveal">
          <p class="eyebrow">Checkout system</p>
          <h2>Cara Kerja Website Kita</h2>
          <p>Kamu bingung gimana cara kerja website kita? Sini mimin kasih tau</p>
        </div>
        <div class="flow reveal">
          <article class="flow-step glass">
            <h3>Buat Akun</h3>
            <p>Masukkan Nama, Email, Dan password kamu. Tenang kami akan simpan baik baik!</p>
          </article>
          <article class="flow-step glass">
            <h3>Pilih Produk</h3>
            <p>Pilih apapun yang kamu butuhkan, Jika yang kamu butuhkan tidak ada hubungi di livechat.</p>
          </article>
          <article class="flow-step glass">
            <h3>Checkout</h3>
            <p>Pilih metode pembayaran dan lakukan checkout, lalu cek emailmu secara berkala.</p>
          </article>
        </div>
      </section>

      <section id="faq" class="section">
        <div class="section-header reveal">
          <h2>FAQ</h2>
          <p>Jawaban singkat untuk pertanyaan yang sering masuk.</p>
        </div>
        <div class="faq-list reveal">
          <details class="faq-item glass">
            <summary>Apakah tersedia migrasi gratis?</summary>
            <p>Ya, tim kami membantu migrasi dasar untuk website yang aktif.</p>
          </details>
          <details class="faq-item glass">
            <summary>Metode pembayaran apa saja yang tersedia?</summary>
            <p>Kami menerima transfer bank, e-wallet, dan virtual account.</p>
          </details>
          <details class="faq-item glass">
            <summary>Bagaimana cara menghubungi support?</summary>
            <p>Gunakan WhatsApp atau Telegram pada bagian Support Contact.</p>
          </details>
        </div>
      </section>

      <section id="support" class="support glass reveal">
        <div class="support-content">
          <h2>Support Contact</h2>
          <p>Pilih jalur kontak yang paling nyaman untuk Anda.</p>
          <div class="cta-actions">
            <a class="btn primary" href="https://wa.me/6285173118646" target="_blank" rel="noreferrer">WhatsApp Support</a>
            <a class="btn ghost" href="https://t.me/aisbirnusantara" target="_blank" rel="noreferrer">Telegram Support</a>
          </div>
        </div>
        <img class="support-image" src="/support.svg" alt="Support" />
      </section>
    </main>

    <footer class="footer glass">
      <div>
        <p class="footer-title">Aisbir Cloud Nusantara</p>
        <p class="footer-text">Cloud hosting untuk semua. Work hour: 08:00 - 21:00</p>
      </div>
      <div class="footer-links">
        <a href="https://status.aisbirnusantara.com" target="_blank" rel="noreferrer">Status</a>
        <a href="https://dash.aisbirnusantara.com" target="_blank" rel="noreferrer">Dashboard</a>
      </div>
    </footer>
  </div>
</template>

<style scoped>
* {
  box-sizing: border-box;
}

:root {
  font-family: "Poppins", "Segoe UI", "Trebuchet MS", sans-serif;
  line-height: 1.6;
  font-weight: 400;
  --ink: #1a1a1a;
  --muted: #666666;
  --accent: #00bcd4;
  --accent-2: #0097a7;
  --bg: #ffffff;
  --glass: rgba(255, 255, 255, 0.9);
  --border: rgba(0, 188, 212, 0.15);
  --shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

body {
  margin: 0;
  background: #ffffff;
  color: var(--ink);
}

a {
  color: inherit;
  text-decoration: none;
}

.page {
  max-width: none;
  margin: 0;
  padding: 28px 0 60px;
  background: #ffffff;
}

.glass {
  background: var(--glass);
  border: 1px solid var(--border);
  box-shadow: var(--shadow);
  backdrop-filter: blur(8px);
}

.nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 14px 18px;
  border-radius: 16px;
  position: sticky;
  top: 16px;
  z-index: 10;
  width: min(1200px, 100%);
  margin: 0 auto;
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.brand-mark {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: grid;
  place-items: center;
  background: var(--accent);
  color: #ffffff;
  font-weight: 700;
  font-size: 1.2rem;
}

.brand-name {
  margin: 0;
  font-weight: 700;
  font-size: 0.95rem;
  letter-spacing: 0.5px;
}

.brand-tag {
  margin: 0;
  font-size: 0.8rem;
  color: var(--muted);
}

.nav-toggle {
  display: none;
}

.nav-toggle-label {
  display: none;
  cursor: pointer;
}

.nav-menu {
  display: flex;
  align-items: center;
  gap: 18px;
  flex: 1;
  justify-content: flex-end;
}

.nav-links {
  display: flex;
  gap: 24px;
  font-size: 0.9rem;
  color: var(--muted);
  flex-wrap: wrap;
}

.nav-links a {
  transition: color 0.2s;
  position: relative;
}

.nav-links a:hover {
  color: var(--accent);
}

.nav-links a.active {
  color: var(--accent);
  font-weight: 600;
}

.nav-links a.active::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--accent);
  border-radius: 999px;
}

.nav-actions {
  display: flex;
  gap: 12px;
  align-items: center;
}

.hero {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 40px;
  align-items: center;
  padding: 40px 24px 60px;
  width: min(1200px, 100%);
  margin: 0 auto;
}

.hero-content h1 {
  font-size: clamp(2.2rem, 3vw, 3.4rem);
  line-height: 1.15;
  margin: 20px 0;
  color: var(--ink);
}

.lead {
  font-size: 1rem;
  color: var(--muted);
  margin: 0 0 24px;
  line-height: 1.6;
}

.eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 14px;
  border-radius: 999px;
  background: rgba(0, 188, 212, 0.1);
  color: var(--accent-2);
  font-size: 0.85rem;
  font-weight: 600;
}

.hero-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 28px;
}

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 600;
  transition: all 0.2s ease;
  text-decoration: none;
}

.btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 188, 212, 0.2);
}

.btn.primary {
  background: var(--accent);
  color: #ffffff;
}

.btn.primary:hover {
  background: var(--accent-2);
}

.btn.ghost {
  background: transparent;
  color: var(--accent);
  border: 1.5px solid var(--accent);
}

.btn.ghost:hover {
  background: rgba(0, 188, 212, 0.08);
}

.hero-metrics {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 16px;
  padding: 20px;
  border-radius: 14px;
  background: rgba(0, 188, 212, 0.05);
  border: 1px solid rgba(0, 188, 212, 0.1);
}

.metric-title {
  margin: 0;
  font-size: 0.8rem;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.03em;
}

.metric-value {
  margin: 6px 0 0;
  font-weight: 700;
  font-size: 1.3rem;
  color: var(--accent);
}

.hero-panel {
  display: grid;
  gap: 16px;
  padding: 20px;
  border-radius: 16px;
}

.panel-card {
  background: rgba(255, 255, 255, 0.6);
  border-radius: 14px;
  padding: 18px;
  border: 1px solid rgba(0, 188, 212, 0.15);
}

.panel-card.accent {
  background: rgba(0, 188, 212, 0.08);
  border: 1px solid rgba(0, 188, 212, 0.25);
}

.panel-title {
  margin: 0;
  color: var(--muted);
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.03em;
}

.panel-value {
  margin: 8px 0 12px;
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--ink);
}

.panel-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.panel-tags span {
  padding: 4px 10px;
  border-radius: 6px;
  background: rgba(0, 188, 212, 0.1);
  color: var(--accent);
  font-size: 0.75rem;
  font-weight: 500;
}

.panel-bars {
  display: flex;
  gap: 6px;
}

.panel-bars span {
  flex: 1;
  height: 6px;
  border-radius: 999px;
  background: rgba(0, 188, 212, 0.15);
}

.panel-bars span:first-child {
  background: var(--accent);
}

.panel-sub {
  margin: 0;
  color: var(--muted);
  font-size: 0.85rem;
}

.section {
  padding: 60px 24px;
  width: min(1200px, 100%);
  margin: 0 auto;
}

.section-header {
  max-width: 640px;
  margin-bottom: 40px;
}

.section-header h2 {
  font-size: clamp(1.8rem, 2.5vw, 2.4rem);
  margin: 0 0 12px;
  color: var(--ink);
}

.section-header p {
  margin: 0;
  color: var(--muted);
  font-size: 1rem;
}

.feature-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
}

.feature-card {
  padding: 24px;
  border-radius: 14px;
  transition: all 0.2s;
}

.feature-card:hover {
  border-color: rgba(0, 188, 212, 0.3);
  box-shadow: 0 4px 16px rgba(0, 188, 212, 0.12);
}

.feature-card h3 {
  margin: 0 0 8px;
  color: var(--ink);
  font-size: 1.1rem;
}

.feature-card p {
  margin: 0;
  color: var(--muted);
  font-size: 0.95rem;
}

.pricing-table {
  display: grid;
  gap: 12px;
  padding: 20px;
  border-radius: 16px;
  overflow-x: auto;
}

.pricing-row {
  display: grid;
  grid-template-columns: 1.1fr 1fr 1.2fr 1fr 0.8fr 0.9fr 0.9fr 1fr;
  gap: 12px;
  align-items: center;
  padding: 14px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.7);
  border: 1px solid rgba(0, 188, 212, 0.1);
}

.pricing-row.highlight {
  border: 1.5px solid var(--accent);
  background: rgba(0, 188, 212, 0.06);
}

.pricing-header {
  font-weight: 700;
  color: var(--muted);
  background: transparent;
  border: none;
  padding-bottom: 8px;
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.tier {
  font-weight: 700;
  color: var(--ink);
}

.status.on {
  color: var(--accent);
  font-weight: 600;
  font-size: 0.9rem;
}

.flow {
  display: grid;
  grid-template-columns: repeat(3, minmax(220px, 1fr));
  gap: 28px;
  align-items: stretch;
}

.flow-step {
  padding: 24px;
  border-radius: 14px;
  position: relative;
  transition: all 0.2s;
}

.flow-step:hover {
  border-color: rgba(0, 188, 212, 0.3);
  box-shadow: 0 4px 16px rgba(0, 188, 212, 0.12);
}

.flow-step h3 {
  margin: 0 0 8px;
  color: var(--ink);
  font-size: 1.1rem;
}

.flow-step p {
  margin: 0;
  color: var(--muted);
  font-size: 0.95rem;
}

.flow-step:not(:last-child)::after {
  content: "→";
  position: absolute;
  right: -20px;
  top: 50%;
  transform: translateY(-50%);
  font-weight: 700;
  color: var(--accent);
  font-size: 1.2rem;
}

.faq-list {
  display: grid;
  gap: 12px;
}

.faq-item {
  border-radius: 12px;
  padding: 16px;
  background: rgba(255, 255, 255, 0.7);
  border: 1px solid rgba(0, 188, 212, 0.1);
}

.faq-item summary {
  cursor: pointer;
  font-weight: 600;
  list-style: none;
  color: var(--ink);
  transition: color 0.2s;
}

.faq-item summary:hover {
  color: var(--accent);
}

.faq-item summary::-webkit-details-marker {
  display: none;
}

.faq-item p {
  margin: 12px 0 0;
  color: var(--muted);
  font-size: 0.95rem;
}

.support {
  margin-top: 40px;
  padding: 40px 24px;
  border-radius: 16px;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 30px;
  align-items: center;
  width: min(1200px, 100%);
  margin-left: auto;
  margin-right: auto;
}

.support-content h2 {
  margin: 0 0 12px;
  color: var(--ink);
  font-size: 1.8rem;
}

.support-content p {
  margin: 0 0 20px;
  color: var(--muted);
}

.support-image {
  width: 100%;
  max-width: 260px;
  justify-self: center;
}

.cta-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.footer {
  margin-top: 60px;
  display: flex;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
  color: var(--muted);
  font-size: 0.9rem;
  padding: 20px 24px;
  border-radius: 14px;
  width: min(1200px, 100%);
  margin-left: auto;
  margin-right: auto;
}

.footer-title {
  margin: 0 0 6px;
  font-weight: 700;
  color: var(--ink);
}

.footer-text {
  margin: 0;
}

.footer-links {
  display: flex;
  gap: 16px;
}

.footer-links a:hover {
  color: var(--accent);
}

.reveal {
  animation: fadeUp 0.9s ease forwards;
  opacity: 0;
}

.delay-1 {
  animation-delay: 0.15s;
}

.delay-2 {
  animation-delay: 0.3s;
}

.delay-3 {
  animation-delay: 0.45s;
}

@keyframes fadeUp {
  from {
    opacity: 0;
    transform: translateY(16px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 900px) {
  .nav {
    flex-wrap: wrap;
    gap: 10px;
    width: calc(100% - 36px);
  }

  .nav-toggle-label {
    display: inline-flex;
    margin-left: auto;
  }

  .nav-menu {
    width: 100%;
    flex-direction: column;
    align-items: flex-start;
    display: none;
    gap: 12px;
    padding-top: 12px;
  }

  .nav-links {
    flex-direction: column;
    gap: 8px;
  }

  .nav-actions {
    width: 100%;
    justify-content: flex-start;
  }

  .nav-toggle:checked ~ .nav-menu {
    display: flex;
  }

  .hero {
    padding-top: 20px;
    gap: 30px;
  }

  .pricing-row {
    grid-template-columns: repeat(2, minmax(100px, 1fr));
  }

  .pricing-header {
    display: none;
  }

  .flow {
    grid-template-columns: 1fr;
  }

  .flow-step::after {
    display: none;
  }

  .flow-step:not(:last-child)::before {
    content: "↓";
    position: absolute;
    bottom: -20px;
    left: 50%;
    transform: translateX(-50%);
    color: var(--accent);
    font-size: 1.2rem;
  }
}

@media (max-width: 600px) {
  .hero {
    grid-template-columns: 1fr;
  }

  .section {
    padding: 40px 16px;
  }

  .nav-links {
    font-size: 0.85rem;
  }
}
</style>
